-- Permet de définir la map selon le niveau
mapList = {}

mapList["tilesheet"] = PATHS.IMG.ROOT .. "dungeontileset-extended.png"
mapList[1] = PATHS.MAPS .. "map_lvl1"
mapList[2] = PATHS.MAPS .. "map_lvl2"
mapList[3] = PATHS.MAPS .. "map_lvl3"
mapList[4] = PATHS.MAPS .. "map_lvl4"
mapList[5] = PATHS.MAPS .. "map_lvl5"
mapList[6] = PATHS.MAPS .. "map_lvl6"
mapList[7] = PATHS.MAPS .. "map_lvl7"
mapList[8] = PATHS.MAPS .. "map_lvl8"

return mapList
