<?xml version = "1.0" encoding = "UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="dungeontileset-extended" tilewidth="16" tileheight="16" tilecount="4096" columns="64">
<image source="../Documents/Cours/GameCoder/_PROJET_1/contents/images/dungeontileset-extended.png" trans="000000" width="1024" height="1024" />
</tileset>
