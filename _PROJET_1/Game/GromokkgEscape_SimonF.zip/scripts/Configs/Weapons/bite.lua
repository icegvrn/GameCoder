bite = {}

bite.name = WEAPONS.TYPE.BITE
bite.damageValue = 1000
bite.speed = 1
bite.range = 7
bite.isRangedWeapon = false
bite.holdingOffset = {0, 0}
bite.sounds = {PATHS.SOUNDS.WEAPONS .. "bite.wav"}
bite.soundsVolume = 0.2

return bite
