none = {}

none.name = WEAPONS.TYPE.NONE
none.damageValue = 0
none.speed = 0
none.range = 7
none.isRangedWeapon = false
none.holdingOffset = {0, 0}
none.sounds = {nil}
none.soundsVolume = 0

return none
